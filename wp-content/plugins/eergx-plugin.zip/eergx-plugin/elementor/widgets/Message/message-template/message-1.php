<div class="message-wrap">
    <p class="message"><?php echo eergx_wp_kses($settings['description']);?></p>
</div>