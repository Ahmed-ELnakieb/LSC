<div class="egx-about-2-right">
    <blockquote class="egx-heading-1 message"><?php echo eergx_wp_kses($settings['description']);?></blockquote>
</div>