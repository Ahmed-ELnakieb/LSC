<div class="egx-explore-3-left">
    <div class="message">
        <span class="subtitle"><?php echo eergx_wp_kses($settings['title']);?></span>
        <h4 class="egx-heading-1 title"><?php echo eergx_wp_kses($settings['description']);?></h4>
    </div>
</div>