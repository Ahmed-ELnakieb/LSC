<div class="shape-1 wow slideInRight" data-wow-duration="2s">
    <img src="<?php echo esc_url($settings['image']['url']);?>" alt="<?php if(!empty($settings['image']['alt'])){ echo esc_attr($settings['image']['alt']);}?>">
</div>