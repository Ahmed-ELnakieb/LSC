<div class="benefit-progress">

    <div class="progress-item">
        <h6 class="egx-heading-1 progress-title"><?php echo esc_html($settings['title']);?></h6>
        <div class="progress">
            <div class="progress-bar" data-percent="<?php echo esc_html($settings['count']);?>"></div>
        </div>
    </div>

</div>