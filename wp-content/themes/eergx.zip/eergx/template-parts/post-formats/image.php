<div class="blog-list-slide-item">
    <?php the_post_thumbnail( 'full', ['class' => 'img-fluid'] );?>
</div>