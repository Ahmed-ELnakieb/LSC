<?php

namespace VendorDuplicator\Aws\Identity\S3;

use VendorDuplicator\Aws\Credentials\Credentials;
class S3ExpressIdentity extends Credentials
{
}
