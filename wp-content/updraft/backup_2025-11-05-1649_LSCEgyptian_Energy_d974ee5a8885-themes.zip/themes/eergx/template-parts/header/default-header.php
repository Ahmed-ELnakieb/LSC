<?php
$socials = cs_get_option('header-socials');
$offcanvas_enable = cs_get_option('offcanvas_enable');
$cart_enable = cs_get_option('cart_enable');
?>
<div class="ftc-header-1-area">
    <div class="container ftc-header-1-container">
        <div class="ftc-header-1-row d-flex align-items-center justify-content-between" >
            <?php eergx_default_logo();?>
        </div>
    </div>
</div>